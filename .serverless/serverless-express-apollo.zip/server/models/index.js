const User = require('./User.js');
const Project = require('./Project.js');

module.exports = { User, Project };
